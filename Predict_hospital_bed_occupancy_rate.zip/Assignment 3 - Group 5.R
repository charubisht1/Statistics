set.seed("1234")

install.packages('actuar')
library(actuar)
library(ggplot2)
library(dplyr)

simulate <- function(number_of_beds, number_of_days) {
  average_patients_in_day <- 14.8 # average patients
  average_stay <- 2.9  # average days
  number_patients <- c() # number of beds occupied for each day length of the beds occupied vector
  beds_occupided <- c() # beds occupied for each day
  beds_occupided_day <- c()
  addmited <- 0 # sum of treated patients
  transported <- 0 #  sum of patients transported to another hospital
  patients_addmited <- c() # number of summed patients admitted for each day
  patients_transported <- c()# number of summed transported patients for each day
  number_of_addmited_patients_day <- c() # number of admitted for specific days
  number_of_transported_patients_day <- c() # number of transported for specific days
  incoming <- c() # incoming patients vector
  duration <- c() # duration stay for each incoming patient each day
  for (i in 1:number_of_days) { # iterate over the number of days
    if (length(beds_occupided) > 0) { # check if there are patient occupying beds
      beds_occupided <- beds_occupided -1 # decrease the amount of stay next day 
      beds_occupided <- beds_occupided[beds_occupided > 0] # filter out patients who are discharged
    }
    incoming_patients <- rpois(1,average_patients_in_day) # generate a random number of incoming patients
    duration_stay <- rzmgeom(incoming_patients, 1/average_stay,0) # generate a random stay duration for each incoming patient  
    beds_occupided <- c(beds_occupided, duration_stay) # add the patients to the beds
    incoming <- c(incoming, incoming_patients) # adds the incoming patients for each day 
    if (length(beds_occupided) > number_of_beds) { # check if the beds are exceeding the limit
      patients_transported_today <- length(beds_occupided) - number_of_beds # number of patients transported to a different hospital 
      transported <- transported + patients_transported_today # sum the number of patients transported
      addmited_from_incoming <- incoming_patients - patients_transported_today  # calculated the addmited patients
      addmited <- addmited + (addmited_from_incoming) # sum of admitted patient after filtering out transported patients
      beds_occupided <- beds_occupided[1:number_of_beds] # keep the  patients to the amount of beds
      number_of_addmited_patients_day <- c(number_of_addmited_patients_day, addmited_from_incoming) # adds the number of admitted patients for specific day after removed transported patients
      number_of_transported_patients_day <- c(number_of_transported_patients_day, patients_transported_today) # adds the number of transported patients for specific day
      if (addmited_from_incoming == 0) {
        duration <- c(duration,  toString("Null")) # adds the duration stay for each incoming patient each day
        
      }else{
        filter_duration <- duration_stay[1:addmited_from_incoming] # adds the addmited patients duration stay
        duration <- c(duration,  toString(filter_duration)) # adds the duration stay for each incoming patient each day
      }
    }else{
      addmited <- addmited + incoming_patients # sum of admitted patients and incoming for each day
      number_of_addmited_patients_day <- c(number_of_addmited_patients_day, incoming_patients) # adds the number of admitted patients for specific day
      number_of_transported_patients_day <- c(number_of_transported_patients_day, 0) # adds the number of transported patients is 0 in this case
      duration <- c(duration,  toString(duration_stay)) # adds the duration stay for each incoming patient each day
    }
    beds_occupided_day <- c(beds_occupided_day, toString(beds_occupided))
    number_patients <- c(number_patients,length(beds_occupided)) # adds the number of occupied beds to the vector of number of patients each day
    patients_addmited <- c(patients_addmited, addmited) # adds the total admitted each day to the vector
    patients_transported <- c(patients_transported, transported) # adds the total transported each day to the vector
  }
  data <- data.frame("Incoming Patients" = incoming,
                     "Daily Addmited" = number_of_addmited_patients_day,  
                     "Total Addmited" =patients_addmited ,
                     "Daily Transported" = number_of_transported_patients_day,
                     "Total transported" = patients_transported,
                     "Number of patients "= number_patients, 
                     "Duration Stay" =duration,
                     "Occupided beds" = beds_occupided_day)
  return(data)
}

plotter <- function(rates, days) {
  # Dummy data
  data <- data.frame(
    day = 1:days,
    value = rates
  )
  
  # Most basic bubble plot
  p <- ggplot(data, aes(x=day, y=value)) +
    geom_line() + xlab("day") + ylab("Occupency Rate")
  p
}

#### simulation of 365 days assuming that its a new hospital  Question 1####
number_of_beds <- 40  # number of beds
number_of_days <- 365 # number of days
x <- simulate(number_of_beds, number_of_days) # simulate the hospital flow
x
number_patients <- x$Number.of.patients. # number of patients
total_transported <- x$Total.transported # number of total transported patients during the number of days provided
daily_transported <-  x$Daily.Transported # daily number of transported patients
total_addmited <- x$Total.Addmited # number of total admitted patients during the number of days provided
daily_addmited <- x$Daily.Addmited # daily number of admitted patients
# Occupancy rate 
rates <- number_patients/number_of_beds
print("Occupency rate: ")
mean(rates)
plotter(rates,number_of_days) 


#### simulation of 3 years Question 1 ####
number_of_beds <- 40 #beds
number_of_days <- 1095 # days
x <- simulate(number_of_beds, number_of_days)
x
number_patients <- x$Number.of.patients. # number of patients
total_transported <- x$Total.transported # number of total transported patients during the number of days provided
daily_transported <-  x$Daily.Transported # daily number of transported patients
total_addmited <- x$Total.Addmited # number of total admitted patients during the number of days provided
daily_addmited <- x$Daily.Addmited # daily number of admitted patients
# Occupancy rate 
third_year <- number_patients[(number_of_days - 364):number_of_days]
print("Occupency rate: ")
rates <- third_year/number_of_beds
mean(rates)
plotter(rates,365) 

#### simulation 10000 days Question 2 ####
number_of_beds <- 40 # beds
number_of_days <- 10000# days
x <- simulate(number_of_beds, number_of_days)
x
total_transported <- x$Total.transported # number of total transported patients during the number of days provided
transported_value <- tail(total_transported, n =1) # total number of transported patients at the end 
total_incoming <- sum(x$Incoming.Patients) # total incoming patients
p_transported <- transported_value/(total_incoming)  # ratio of lost patients
print("probability of transported to another hospital: ")
print(p_transported)


#### Required number of beds at the hospital ####
required_beds <- c() # number of required beds
number_of_days <- 10000 # number of days
n <- 5 # number of observation
for (i in 1:n) { # run N number of observations
  beds_rates <- c() # occupancy rate for the days under or = 85% 
  beds_to_test <- seq(40,70) # run from 40 to 70 beds
  for (number_of_beds in beds_to_test){ 
    x <- simulate(number_of_beds, number_of_days) # simulate the hospital
    number_patients <- x$Number.of.patients. # number of patients
    rates <- number_patients/number_of_beds # occupancy rate 
    mean_under_85percent <- mean(rates <= 0.85) # mean of occupancy rate for the good days which is the occupancy rate under/= 85%
    beds_rates <- c(beds_rates, mean_under_85percent) # adds the mean to the vector
  }
  number_of_beds <- beds_to_test[min(which(beds_rates > 0.95))] # check the first good day which is mean of rates under/= 85% and get the bed number
  required_beds <- c(required_beds, number_of_beds) # adds the bed number to the vector
}
fav_bed <- round(mean(required_beds)) # get the mean of favorable bed
number_patients <- simulate(fav_bed, number_of_days)$Number.of.patients. # simulate with the fav bed
rate <- number_patients/number_of_beds # occupancy rates 
bed_rate <-  mean(rate <= 0.85) #  take the mean of the rates are under 85%