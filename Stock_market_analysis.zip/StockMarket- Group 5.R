
library(quantmod) # get stock prices; useful stock analysis functions
library(stringr) # working with strings
library(corrplot) # for plotting correlation
library(PerformanceAnalytics) # evaluating the performance and  risk  characteristics  of  financial  assets  or  funds
#Loads the company stock using ticker
library(ggplot2)

getSymbols("MSFT",from="2009-10-01",to="2021-09-30",src="yahoo") # Microsoft 
getSymbols("AAPL",from="2009-10-01",to="2021-09-30",src="yahoo") # Apple 
getSymbols("INTC",from="2009-10-01",to="2021-09-30",src="yahoo") #Intel
getSymbols("KO",from="2009-10-01",to="2021-09-30",src="yahoo")  # Coca Cola
getSymbols("WMT",from="2009-10-01",to="2021-09-30",src="yahoo") #Walmart



#Stock returns in log
MSFT_log_returns<-dailyReturn(MSFT,type='log')
INTC_log_returns<-dailyReturn(INTC,type='log')
APPL_log_returns<-dailyReturn(AAPL,type='log')
KO_log_returns<-dailyReturn(KO,type='log')
WMT_log_returns<-dailyReturn(WMT,type='log')
MSFT_log_returns
#Mean of log stock returns 

MSFT_mean_log<-mean(MSFT_log_returns)
INTC_mean_log<-mean(INTC_log_returns)
APPL_mean_log<-mean(APPL_log_returns)
KO_mean_log<-mean(KO_log_returns)
WMT_mean_log<-mean(WMT_log_returns)
MSFT_mean_log
#round it to 4 decimal places

mean_log<-c(INTC_mean_log,APPL_mean_log,KO_mean_log,MSFT_mean_log,WMT_mean_log)
mean_log<-round(mean_log,4)
mean_log
#standard deviation of log stock returns

MSFT_sd_log<-sd(MSFT_log_returns)
INTC_sd_log<-sd(INTC_log_returns)
APPL_sd_log<-sd(APPL_log_returns)
KO_sd_log<-sd(KO_log_returns)
WMT_sd_Log<-sd(WMT_log_returns)
MSFT_sd_log
#round it to 4 decimal places 

sd_log<-c(INTC_sd_log,APPL_sd_log,KO_sd_log,MSFT_sd_log,WMT_sd_Log)
sd_log<-round(sd_log,4)
sd_log
#create data frame

graphic1<-data.frame(rbind(c("INTC",INTC_mean_log,INTC_sd_log),
                           c("AAPL",APPL_mean_log,APPL_sd_log),
                           c("MSFT",MSFT_mean_log,MSFT_sd_log),
                           c("KO",KO_mean_log,KO_sd_log),
                           c("WMT",WMT_mean_log,WMT_sd_Log)),stringsAsFactors = FALSE)


graphic2<-data.frame(rbind(c("INTC",round(INTC_mean_log,4),round(INTC_sd_log, 4)),
                           c("AAPL",round(APPL_mean_log,4), round(APPL_sd_log, 4)),
                           c("MSFT",round(MSFT_mean_log,4),round(MSFT_sd_log,4)),
                           c("KO",round(KO_mean_log,4),round(KO_sd_log, 4)),
                           c("WMT",round(WMT_mean_log,4),round(WMT_sd_Log,4))),stringsAsFactors = FALSE)
colnames(graphic2)<-c("Share","Mean_Log_Return", "Sd_Log_Return")
View(graphic2)


#rownames(graphic1)<-c("INTC","APPL","MSFT","KO","WMT")
colnames(graphic1)<-c("Share","Mean_Log_Return", "Sd_Log_Return")
View(graphic1)
#Data frame contains the 5 companies with each company's average log return and standard deviation.
plot(Sd_Log_Return~Mean_Log_Return,data=graphic1,type="p",pch=(substring(graphic1$Share,1,1)))
#Use R to observe a stock's performance
#chart components: bollinger bands, % bollinger change, volume, moving average convergence divergence

chartSeries(AAPL,bar.type = "ohlc",theme="white",subset="2020",up.col="green",dn.col="red")
addBBands(n=20,sd=2)


chartSeries(MSFT,bar.type = "ohlc",theme="white",subset="2020",up.col="green",dn.col="red")
addBBands(n=20,sd=2)

chartSeries(KO,bar.type = "ohlc",theme="white",subset="2020",up.col="green",dn.col="red")
addBBands(n=20,sd=2)

chartSeries(INTC,bar.type = "ohlc",theme="white",subset="2020",up.col="green",dn.col="red")
addBBands(n=20,sd=2)

chartSeries(WMT,bar.type = "ohlc",theme="white",subset="2020",up.col="green",dn.col="red")
addBBands(n=20,sd=2)

normalise_series <- function(xdat) xdat / coredata(xdat)[1]

chart_Series(Cl(MSFT), name="the five companies")
add_TA(Cl(AAPL), on = 1, col = "red")
add_TA(Cl(KO), on = 1, col = "black")
add_TA(Cl(WMT), on = 1, col = "green")
add_TA(Cl(INTC), on = 1, col = "blue")

chart_Series(normalise_series(Cl(MSFT)), on = 1, col = "orange",lty = 1 ,name="the five companies normalized")
add_TA(normalise_series(Cl(MSFT)), on = 1, col = "orange",lty = 1)
add_TA(normalise_series(Cl(AAPL)), on = 1, col = "red", lty = 1)
add_TA(normalise_series(Cl(KO)), on = 1, col = "black", lty = 1)
add_TA(normalise_series(Cl(WMT)), on = 1, col = "green", lty = 1)
add_TA(normalise_series(Cl(INTC)), on = 1, col = "blue", lty = 1)



#check correlation of different companies
data2<-cbind(diff(log(Cl(INTC))),diff(log(Cl(WMT))),diff(log(Cl(MSFT))),diff(log(Cl(AAPL))),diff(log(Cl(KO))))
View(data2)
#library(corrplot)
corrplot(cor(na.omit(data2)))

#Monte Carlo: Rooted in past performance is not an indicator of future results. Price fluctuations can not be predicted with accuracy

mu<-MSFT_mean_log
sig<-MSFT_sd_log
#testsim<-rep(NA,1000)

#generate random daily exponent increase rate using MSFT's mean and sd log returns

#one year 252 trading days, simulate for 4 years 
# 4*252 trading days
set.seed(1234)

T<-252*4
price<-rep(NA,T)

#most recent colsing price
price[1]<-as.numeric(MSFT[(dim(MSFT))[1],4])
price[1]
#start simulating prices

for(i in 2:T){
  price[i]<-price[i-1]*exp(rnorm(1,mu,sig))
}




plot(price~seq(1,T), type="l",xlab="Day",ylab="Price")
#monte carlo simulation: incredibly useful forecasting tool to predict outcomes of events with many random variables

N<-300
mc_matrix<-matrix(nrow=T,ncol=N)
mc_matrix[1,1]<-as.numeric(MSFT[(dim(MSFT))[1],4])

for(j in 1:ncol(mc_matrix)){
  mc_matrix[1,j]<-as.numeric(MSFT[(dim(MSFT))[1],4])
  for(i in 2:nrow(mc_matrix)){
    mc_matrix[i,j]<-mc_matrix[i-1,j]*exp(rnorm(1,mu,sig))
  }
}
matplot(as.data.frame(mc_matrix),type="l",xlab = "days", 
        ylab = "price", main= "Monte carlo 300 simulations for Microsoft",lwd = 0.3 , col = "black")

max(mc_matrix) # max value in the matrix
min(mc_matrix) # min value in the matrix

last_prices <- mc_matrix[nrow(mc_matrix),1:ncol(mc_matrix)] # extract the last price for each simulation
summary(last_prices) # summary of last prices
sd(last_prices) # sd for last prices
mean(last_prices> price[1])  # probability of ganing a profit
mean(last_prices)/price[1] # number of folds we gain 



################################

#Code Question 7 here
set.seed(1234)

# https://www.geeksforgeeks.org/best-time-to-buy-and-sell-stock/
maxProfit <- function(price, n) {
  buy <- price[1]
  min <- 1
  max <- 1
  max_profit <- 0
  for (i in 2:n) {
    ## Checking for lower buy value
    if (buy > price[i]) {
      buy = price[i]
      min <- i
      ## Checking for higher profit
    }else if (price[i] - buy > max_profit) {
      max_profit = price[i] - buy;
      max <- i
    }
  }
  return(data.frame("min index" = c(min), "max index"= c(max), "min value" = c(price[min]), "max value" = c(price[max]), "max profit" = c(max_profit)))
}


MSFT_shares <- 0.7 # amount of shares for Micosoft
WMT_shares <- 0.3 # amount of shares in Walmart
# the variaice of portfolio
AAPL_WMT_var <- ((MSFT_shares **2) * (MSFT_sd_log **2) + (WMT_shares **2) * (WMT_sd_Log **2) + 2 * MSFT_shares * WMT_shares * cov(cbind(MSFT_log_returns, WMT_log_returns)))[1]

N<-300
mu<-MSFT_shares*MSFT_mean_log+WMT_shares*WMT_mean_log
sig<-sqrt(AAPL_WMT_var)
mc_matrix<-matrix(nrow=T,ncol=N)
mc_matrix[1,1]<-as.numeric(MSFT[(dim(MSFT))[1],4])

for(j in 1:ncol(mc_matrix)){
  mc_matrix[1,j] <- as.numeric(WMT[(dim(WMT))[1],4]) * WMT_shares + as.numeric(MSFT[(dim(MSFT))[1],4]) * MSFT_shares
  for(i in 2:nrow(mc_matrix)){
    mc_matrix[i,j]<-mc_matrix[i-1,j]*exp(rnorm(1,mu,sig))
  }
}
matplot(as.data.frame(mc_matrix),type="l",xlab = "days", 
        ylab = "price", main= "Monte carlo 300 simulations for Microsoft and Walmart",lwd = 0.3 , col = "black")

max(mc_matrix) # max value in the matrix
min(mc_matrix) # min value in the matrix

last_prices <- mc_matrix[nrow(mc_matrix),1:ncol(mc_matrix)] # extract the last price for each simulaton
summary(last_prices) # summary of for the last prices

profit <- c() # the profit when is it best to buy and sell
for (j in 1:N) {
  x <-  maxProfit(c(mc_matrix[,j]) , length(mc_matrix[,j]))
  profit <- c(profit, x)
}
tail(profit)
sd(last_prices)  # sd for the last prices
mean(last_prices> price[1]) # the probability of gaining a profit
mean(last_prices)/price[1] # number of folds we gain



